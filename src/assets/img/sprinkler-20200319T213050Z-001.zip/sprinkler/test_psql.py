import psql_conn.py

cursor.execute()