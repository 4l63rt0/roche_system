class Zones:
	def __init__(self, gpio, name, status):
		self.gpio = gpio
		self.name = name
		self.status = status

zone1 = Zones(17, 'zone1', 0)
zone2 = Zones(27, 'zone2', 0)
zone3 = Zones(22, 'zone3', 0)

print(zone1.name)

