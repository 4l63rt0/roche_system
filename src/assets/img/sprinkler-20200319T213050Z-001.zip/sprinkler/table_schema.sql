drop table if exists zones;
drop table if exists scheduler;
drop table if exists controller;

PRAGMA foreign_keys = ON; --Enables foreign keys on schema

create table zones (
	gpio int primary key, --Using BMC mode
	name text unique not null,
	status int DEFAULT 0 -- enable, disable
);

create table scheduler (
	schedule_name text primary key,
	month int,
	day int,
	week int,
	day_of_week int,
	hour int,
	minute int,
	status int
);

create table controller (
	controller_name text primary key,
	time_on int,
	gpio int,
	schedule_name text,
	status int,
	foreign key(gpio) references zones(gpio),
	foreign key(schedule_name) references scheduler(schedule_name)
);

INSERT INTO zones VALUES (17, 'zone1', 0);
INSERT INTO zones VALUES (27, 'zone2', 0);
INSERT INTO zones VALUES (22, 'zone3', 0);
INSERT INTO zones VALUES (23, 'zone4', 0);
INSERT INTO zones VALUES (24, 'zone5', 0);

.headers on
.mode column
