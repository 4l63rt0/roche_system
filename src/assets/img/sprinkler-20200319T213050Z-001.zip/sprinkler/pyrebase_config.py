import pyrebase

config = {
	"apiKey": "AIzaSyBS3z09tIl1AKTsmxiOthp5AHClqJxJkwc",
    "authDomain": "sprinkler-pi.firebaseapp.com",
    "databaseURL": "https://sprinkler-pi.firebaseio.com",
    "projectId": "sprinkler-pi",
    "storageBucket": "sprinkler-pi.appspot.com",
    "messagingSenderId": "730633032617"
}

firebase = pyrebase.initialize_app(config)

db = firebase.database()


# Adding new values
# db.child("zones").child("zone4").set({"name":"zone4",
# 	"gpio":23,
# 	"time":1,
# 	"scheduler":1,
# 	"status":True
# 	})

# Updating values 
# db.child("zones").child("zone2").update({"status":True})

# Read values 
# read = db.child("zones").get()
# print(read.val())