from flask import Flask, render_template, request, url_for, redirect, flash
import RPi.GPIO as GPIO
import time
import datetime
from forecastiopy import *
import atexit
from apscheduler.schedulers.background import BackgroundScheduler
import sqlite3
import re

app = Flask(__name__)

#Current time will be displayed in page
now = datetime.datetime.now()

# Used with flash
app.secret_key = 'Alb3rt0'

#Refering pins of RPi Zero by Broadcom SOC Channel
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
print('SETTING GPIOs MODE')


#Connect or Create DB File
def sqlite_zoneList():
	conn = sqlite3.connect("sprinkler_pi_db")
	curs = conn.cursor()
	getZones = curs.execute("SELECT * FROM zones")
	rowsZones = curs.fetchall()
	curs.close()
	conn.close()
	return rowsZones


# Set each pin as an output and set it low:
for value in sqlite_zoneList():
	GPIO.setup(value[0], GPIO.OUT)
	GPIO.output(value[0], GPIO.LOW)


#Dark Sky key and location used to forecast weather
api_key = "8d37c16d7b641dfe058222f2f8a89eb1"
location = ["27.5909302", "-99.4883051"]
#Initiation of ForecastIO Class
fio = ForecastIO.ForecastIO(api_key,
                            units=ForecastIO.ForecastIO.UNITS_US,
                            lang=ForecastIO.ForecastIO.LANG_ENGLISH,
                            latitude=location[0], longitude=location[1])


category = ""

def print_date_time():
    print(time.strftime("%A, %d. %B %Y %I:%M:%S %p"))

#Check weather condition of your location
def weatherConditions():
	if fio.has_daily() is True:
		daily = FIODaily.FIODaily(fio)
		tempLow = (daily.get_day(1)['temperatureLow'])
		precipIntensity = (daily.get_day(1)['precipIntensity'])
		#print("Tomorrow's conditions: "+ dsIcon)
		#print("Tomorrow's lowest temperature: "+ str(tempLow))
		return tempLow, precipIntensity

my_tempLow, my_precipIntensity = weatherConditions()

def activateZones():
	print("ACTIVATEZONES STARTED")
	print('Precipitation Intensity: ' + str(my_precipIntensity))
	print('Low temperature of the day: ' + str(my_tempLow))
	if (my_tempLow > 45.0) or (my_precipIntensity > 0.0017) :
		print("Temperature higher than 35 and/or")
		print("Precipitation Intensity highger than 0.017 in")
		for value in sqlite_zoneList():
			if value[2] == 1:
				print('Valve ' + str(value[1] + ' starting'))
				time.sleep(1)
				GPIO.output(value[0], GPIO.HIGH)
				print(str(value[0]) + " : " + "HIGH" )
				time.sleep(1)
				GPIO.output(value[0], GPIO.LOW)
				print(str(value[0]) + " : " + "LOW" )
				print('Valve ' + str(value[1]) + (' is done!'))
	else:
		print('Next run CANCELED due to weather conditions')
		print('Precipitation Intensity: ' + str(my_precipIntensity))
		print('Low temperature of the day: ' + str(my_tempLow))

# Index Route
@app.route('/', methods=['POST', 'GET'])
def index():

	#Displays date and time on index
	displayDateTime = now.strftime("%Y-%m-%d %H:%M:%S")

	if fio.has_daily() is True:
		daily = FIODaily.FIODaily(fio)
		dailySumary = daily.summary
		strPrecipProbability = str(daily.get_day(0)['precipProbability'])

	if request.method == 'POST':
		valve = request.form['valve']
		relayTime = request.form['time']
		if valve=="Valve..." or relayTime=="Time..." :
			category = 'warning'
			flash('Please select both options, "Valve" and "Time"', category)

			return render_template('index.html', category=category,
									dailySumary=dailySumary,
									strPrecipProbability=strPrecipProbability,
									zoneList=sqlite_zoneList())

		GPIO.output(int(valve), GPIO.HIGH)
		category = "info"
		flash('Valve test sent successfuly', category)
		time.sleep(int(relayTime))
		GPIO.output(int(valve), GPIO.LOW)
		flash('Valve test has finished', category)

		return redirect('/')

	return render_template('index.html',
							displayDateTime=displayDateTime,
							dailySumary=dailySumary,
							strPrecipProbability=strPrecipProbability,
							zoneList=sqlite_zoneList())

@app.route('/config', methods=['POST', 'GET'])
def config():
	#Connect or Create DB File
	conn = sqlite3.connect("sprinkler_pi_db")
	curs = conn.cursor()
	getZones = curs.execute("SELECT * FROM zones")
	rowsZones = curs.fetchall()
	if request.method == 'POST':
		getValue = request.form['action']
		getGPIO = re.sub("[^0-9]", "", getValue)
		if getValue.startswith('edit'):
			print(getValue)
			print(getGPIO)
			return redirect(url_for('updateZone', getGPIO=getGPIO))
		elif getValue.startswith('gpio'):
			print(getValue)
			curs.execute("UPDATE zones SET status = NOT status WHERE gpio = " + str(getGPIO))
			conn.commit()
			curs.close()
			conn.close()
			category = "info"
			flash("GPIO " + getGPIO + " was updated", category)
			return redirect('/config')
		elif getValue.startswith('delete'):
			print(getValue)
			curs.execute("DELETE FROM zones WHERE gpio = " + str(getGPIO))
			conn.commit()
			curs.close()
			conn.close()
			category = "info"
			flash("GPIO " + getGPIO + " was deleted", category)
			return redirect('/config')
	return render_template('config.html', rowsZones=rowsZones, )


@app.route('/addZone', methods=['POST', 'GET'])
def addZone():
	#Connect or Create DB File
	conn = sqlite3.connect("sprinkler_pi_db")
	curs = conn.cursor()
	if request.method == 'POST':
		newGpio = str(request.form['newGpio'])
		newName = str(request.form['newName'])
		if (newGpio != '') and (newName != ''):
			curs.execute("INSERT INTO zones (gpio,name,status) VALUES (?,?,?)", (newGpio,newName,0))
			conn.commit()
			curs.close()
			conn.close()
			category = "success"
			flash("New Zone named (" + newName + ") created", category)
			return	redirect('/config')
		else:
			category = "danger"
			flash("Both input text fields need to be entered", category)
			return redirect('/addZone')
	return render_template('addZone.html')

@app.route('/updateZone/<getGPIO>', methods=['POST', 'GET'])
def updateZone(getGPIO):
	#Connect or Create DB File
	conn = sqlite3.connect("sprinkler_pi_db")
	curs = conn.cursor()
	getName = curs.execute("SELECT name FROM zones WHERE gpio =" + str(getGPIO))
	zoneName = " ".join([x[0] for x in curs.fetchall()])
	if request.method == 'POST':
		updateName = str(request.form['updateName'])
		if (updateName != '') and (updateName != zoneName):
			curs.execute("UPDATE zones SET name = '" + updateName + "' WHERE gpio = " + str(getGPIO))
			conn.commit()
			curs.close()
			conn.close()
			category = "success"
			flash("Zone named (" + zoneName + ") updated to " + updateName, category)
			return	redirect('/config')
		else:
			category = "danger"
			flash("Zone name cannot be repeated or empty", category)
			return redirect('/updateZone/' + getGPIO)
	return render_template('updateZone.html', getGPIO=getGPIO, zoneName=zoneName)

#Staring the APScheduler module
scheduler = BackgroundScheduler()
scheduler.start()
scheduler.add_job(activateZones, 'cron', minute='*/2')

# Shut down the scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())
atexit.register(lambda: GPIO.cleanup())

if __name__ == '__main__':
	app.debug = True
	app.run(host='0.0.0.0')
